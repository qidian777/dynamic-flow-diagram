---
name: dynamic-flow-diagram
display_name: 动态流程图生成器
display_name_en: Dynamic Flow Diagram Builder
description: 把 Visio(.vsdx)、图片、表格或文字描述的业务流程，转成单文件可交互 HTML——单图模式是动态流程图（标准图形、冻结泳道、悬停说明、自动演示）；工作台模式把全公司多张流程装进一个 HTML：总览、流程索引（搜索+按部门/角色/系统筛选）、子流程串联跳转、跨流程岗位统计、术语/断链/职责一致性检查。当用户提到 Visio/vsdx、流程图、泳道图、流程梳理、流程培训、岗位流程、流程体系、多张流程、流程工作台、把流程做成可点击的网页时使用。
description_zh: 把 Visio 或文字描述的流程转成单文件可交互动态流程图：标准图形、冻结泳道、阶段筛选、悬停说明、演示动画。面向培训与评审场景。
description_en: Turn Visio or text-described business processes into a single-file interactive HTML flow diagram with standard flowchart shapes, frozen swimlanes, phase filters, hover notes, and step-by-step playback.
examples_zh:
  - "把这个 vsdx 里的样衣管控流程做成动态流程图"
  - "按岗位看看业务员在流程里要做哪几步"
  - "把这段流程说明做成能演示的网页，培训用"
examples_en:
  - "Turn the procurement process in this .vsdx into an interactive diagram"
  - "Show me the returns flow from the salesperson's point of view"
  - "Make this process description into a page I can present in training"
version: 2.0.0
author: 施鸿雁（美美虾-阿羽）
license: MIT
allowed-tools: Read, Write, Edit, Bash, ViewImage
---

# 动态流程图生成器

把业务流程图从「一张静态图片」升级为「一件会讲解的工具」。产出物永远是**单个 HTML 文件**：双击即用、无需联网、可直接发给同事。

## 什么时候用 / 不用

| 用 | 不用 |
|---|---|
| 流程培训、新人带教、评审汇报 | 需要真实系统联动的可执行流程引擎 |
| 把 Visio/Axure 老图变成可交互版本 | 只要一张静态配图（直接截图更快） |
| 梳理「谁在什么阶段做什么」 | 架构图、思维导图（形态不同） |
| 流程变更前后对比讲解 | 数据看板（用图表类技能） |

## 两种模式，先选后做

| | 单图模式（v1） | 工作台模式（v2） |
|---|---|---|
| 场景 | 一张流程图的培训/评审 | 全公司多张流程的体系梳理 |
| 产出 | 一个 HTML 动态流程图 | 一个 HTML 流程工作台（五视图） |
| 数据 | 直接改 template.html 里的数组 | 中央清单 manifest → 构建脚本 |
| 坐标 | 手写 x/y | 自动布局（拓扑分层 + 泳道定列） |
| 判断依据 | 用户只给了一张图/一个流程 | 用户提到"所有流程/多张流程/流程体系"，或流程之间存在子流程引用 |

单图模式走下面"五步工作流"；工作台模式先读 `@references/workbench-spec.md`。

## 工作台模式六步

1. **取材**：三种入口殊途同归——vsdx 逐页解析、Excel 清单、口述建模，终点都是 manifest
2. **建字典**：先定部门/角色/系统三张全局表，和客户确认口径，再动手写流程
3. **写 manifest**：参考 `@examples/demo-manifest.yaml` 的结构；坐标不用写
4. **体检**：`python scripts/build_workbench.py <manifest> --check`，断链和术语问题先清后建
5. **构建**：`-o` 产出单文件 HTML；`--strict` 用于交付把关
6. **验收**：`node scripts/shot_workbench.js <html> <shots>` 跑七图断言，再按 workbench-spec 的四条附加项过一遍

工作台的铁律（在 v1 七条之上追加）：
- **manifest 是唯一事实**。要改流程改 manifest 重新构建，永远不要直接改产出的 HTML
- **字典先行**。角色和系统口径没和客户对齐之前，不写节点
- **`--strict` 不过不交付**。断链是"点击就 404"级别的问题

## 五步工作流（单图模式）

### 第 1 步：取材
- `.vsdx` → 跑 `scripts/parse_vsdx.py`（见 `references/layout-rules.md` 里"解析"一节）；多页文件先看 `pages.xml` 选结构最全的一页，动手前跟用户确认选哪页
- `.vsd`（旧二进制）→ 请用户另存为 `.vsdx`，或提供 PDF/高清截图
- 图片/PDF → 按版面人工重建，节点文字必须回读给用户确认
- 纯文字流程 → 直接建模，缺的角色/系统先按"待确认"标注

### 第 2 步：建模（先数据后图形）
先把流程抽成四张表再动手写 HTML，跳过这步一定返工：

1. **阶段（PHASES）**：纵向分段，如 入库/借出/归还/报废
2. **泳道（LANES）**：横向分列，按角色，如 IT/业务/样衣管理员
3. **节点（NODES）**：`{id, 编号, 阶段, 泳道, x, y, 类型, 文本, 岗位, 系统, 说明}`
4. **连线（EDGES）**：`{起点, 终点, 标签}`，标签就是分支条件（是/否/外协/自制）

节点类型严格映射到标准流程图图形，见下表。

### 第 3 步：布局
按 `references/layout-rules.md` 的栅格参数排。原则只有一条：**同一列只放同一条主路径**，分支横向展开，不为了紧凑而斜插节点。

### 第 4 步：渲染
基于 `assets/template.html` 改数据即可，不要从零写。模板已内置：标准图形 SVG、冻结泳道条、悬停气泡、详情抽屉、演示动画、缩放平移。

### 第 5 步：验收
必须按 `references/qa-checklist.md` 逐条过，并用 `scripts/shot.js` 截图自查。**不截图就交付 = 没做。**

## 七条铁律

这些是真实返工换来的，优先级高于任何审美偏好。

**1. 图形必须是标准流程图符号，不能自创**
矩形代表作业、菱形代表判断，员工在 Visio/PPT 里认识这套语言，换形状等于增加认知负担。

| 语义 | 图形 | 用例 |
|---|---|---|
| 起止 | 圆角胶囊 | 流程开始、结束状态 |
| 作业 | 矩形 | 绝大多数动作步骤 |
| 判断 | 菱形 | 需要分支的节点 |
| 数据 | 平行四边形 | 系统产出物、单据 |
| 系统操作 | 圆柱 | 数据库读写、批量录入 |
| 子流程 | 双线矩形 | 引用另一张流程图 |

菱形高度要给到矩形 1.7 倍左右，否则文字挤成三行。

**2. 浮层永远不许压住主内容**
这是最高频的用户抱怨。任何气泡、面板、提示都必须满足：
- 悬停说明放在节点**左右两侧**，垂直居中对齐，绝不放上下（上下就是流程前进方向）
- 落位前检测是否与其他节点相交，相交则沿垂直方向找最近空档
- 侧边清单默认收起，画布优先；宽屏才默认展开
- 迷你地图、缩略图这类"锦上添花"的控件，一旦挡图就删掉，不要试图挪位置

**3. 信息分三层，不要一次全给**
- 扫一眼 → 悬停气泡（一句话说明 + 岗位 + 系统）
- 看单步 → 点击节点开抽屉（上下游可点击跳转）
- 系统读 → 顶部"流程说明"弹窗（原文全文）

**4. 泳道标题要冻结**
参照 Excel 冻结窗格：标题条固定在页面顶部，横向跟随缩放平移，纵向不动。缩得很小时字号自适应，再小就淡出，不要挤成一团。

**5. 坐标只写一份**
节点位置用 `{x, y}` 中心点存在 JS 数据里，DOM 与连线 SVG 都从这份数据算。出现"节点被拖走了但线没动"，一定是坐标被写了两份。

**6. 中文排版按阅读习惯**
正文 12.5px 起，行高 1.35；节点内最多两行，超出就拆节点而不是缩字号；角色配色全图统一，同一个岗位永远同一种颜色。

**7. 演示要能停下来**
自动演示必须有：当前节点高亮 + 连线流动动画 + 步骤进度提示 + 随时可停 + 结束回到全图。培训时讲师随时会打断，不能卡在中间状态。

## 常见返工原因对照

| 现象 | 根因 | 正解 |
|---|---|---|
| 用户说"说明在哪" | 只画了图，没放文字说明 | 三层信息同时给 |
| 用户说"挡住流程图了" | 浮层默认展开、位置压在图上 | 铁律 2 |
| 用户说"不是标准图形" | 用了自定义卡片样式 | 铁律 1 |
| 用户说"看不懂谁做什么" | 只有节点没有岗位维度 | 加按岗位筛选视图 + 动作清单 |
| 用户说"讲的时候找不到" | 没有聚焦/演示机制 | 阶段筛选 + 自动演示 |
| 文字溢出框外 | 字号写死、节点高度写死 | 高度按类型算，超两行拆节点 |

## 交付话术

交付时说明三件事，能挡掉一半追问：文件在哪、怎么用（三个动作）、哪些地方做了推断需要确认。不要罗列功能清单。

## 参考资料

- `@references/layout-rules.md` — vsdx 解析方法、栅格参数、连线路径算法
- `@references/interaction-spec.md` — 交互清单与实现要点、踩坑记录
- `@references/workbench-spec.md` — 工作台模式：manifest 结构、自动布局、检查规则、五视图规格
- `@references/qa-checklist.md` — 交付前逐条验收
- `@assets/template.html` — 单图模式：可直接改数据的工作骨架
- `@assets/workbench.html` — 工作台模式：五视图模板（由构建脚本注入数据，不直接改）
- `@examples/demo-manifest.yaml` — 工作台 manifest 完整示例（虚构数据，含故意埋的问题）
- `@scripts/parse_vsdx.py` — .vsdx → JSON
- `@scripts/build_workbench.py` — manifest 校验 + 一致性检查 + 构建 HTML
- `@scripts/shot.js` / `@scripts/shot_workbench.js` — 单图 / 工作台截图自查
- `@scripts/validate_skill.py` — 技能包完整性校验
